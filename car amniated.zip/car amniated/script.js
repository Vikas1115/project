var audio = document.createElement('audio');
audio.setAttribute('src', 'v.mp3');
audio.loop = true;
audio.play();