const quotes = [
  "I wake up early every morning.",
  "She brushes her teeth twice a day.",
  "They go for a walk in the evening.",
  "He drinks coffee before work.",
  "We cook dinner together on weekends.",
  "The sun rises in the east.",
  "I read the newspaper daily.",
  "She waters the plants every morning.",
  "They clean the house on Saturdays.",
  "He takes the dog for a walk.",
  "We watch movies on Fridays.",
  "I write in my journal every night.",
  "She listens to music while cooking.",
  "They exercise at the gym regularly.",
  "He checks his emails in the morning.",
  "We go grocery shopping on Sundays.",
  "I prepare lunch for my kids.",
  "She drives to work every day.",
  "They take a nap after lunch.",
  "He reads a book before bed.",
  "Please send me the report by noon.",
  "I will attend the meeting at 3 PM.",
  "She is working on the new project.",
  "They are discussing the quarterly results.",
  "He submitted the proposal yesterday.",
  "We need to finalize the budget.",
  "I will call you after the meeting.",
  "She is preparing the presentation slides.",
  "They are organizing the team-building event.",
  "He is reviewing the contract details.",
  "We are planning the annual conference.",
  "I will update the document accordingly.",
  "She is coordinating with the vendors.",
  "They are analyzing the market trends.",
  "He is drafting the email response.",
  "We need to schedule a follow-up meeting.",
  "I will share the agenda shortly.",
  "She is compiling the feedback received.",
  "They are setting up the conference room.",
  "He is arranging the client meeting.",
  "I need to buy groceries today.",
  "She is shopping for a new dress.",
  "They are looking for a birthday gift.",
  "He is comparing prices online.",
  "We are visiting the supermarket.",
  "I forgot to buy milk.",
  "She is checking out at the counter.",
  "They are browsing the electronics section.",
  "He is returning the faulty product.",
  "We are waiting in the billing queue.",
  "I found a great deal on shoes.",
  "She is trying on the jacket.",
  "They are selecting fresh vegetables.",
  "He is paying with his credit card.",
  "We are collecting the online order.",
  "I need to pick up the laundry.",
  "She is mailing a package.",
  "They are refueling the car.",
  "He is withdrawing cash from the ATM.",
  "We are dropping off the parcel.",
  "I love eating Italian cuisine.",
  "She is baking a chocolate cake.",
  "They are dining at a new restaurant.",
  "He is cooking pasta for dinner.",
  "We are ordering takeout tonight.",
  "I prefer spicy food.",
  "She is making a fruit salad.",
  "They are trying a new recipe.",
  "He is grilling chicken on the barbecue.",
  "We are having lunch at the cafe.",
  "I am craving some ice cream.",
  "She is preparing breakfast for the family.",
  "They are enjoying a cup of coffee.",
  "He is slicing the vegetables.",
  "We are setting the table for dinner.",
  "I am boiling water for tea.",
  "She is frying eggs for breakfast.",
  "They are toasting bread slices.",
  "He is serving the dessert.",
  "We are cleaning up after the meal.",
  "I am booking a flight to Delhi.",
  "She is packing her suitcase.",
  "They are checking into the hotel.",
  "He is boarding the train.",
  "We are exploring the city.",
  "I need to renew my passport.",
  "She is applying for a visa.",
  "They are renting a car.",
  "He is navigating using GPS.",
  "We are visiting historical sites.",
  "I am taking a road trip.",
  "She is booking accommodation online.",
  "They are traveling by bus.",
  "He is catching a cab.",
  "We are waiting at the airport lounge.",
  "I am checking the flight status.",
  "She is going through security check.",
  "They are boarding the cruise ship.",
  "He is buying train tickets.",
  "We are planning our itinerary.",
  "I am attending an online course.",
  "She is studying for her exams.",
  "They are participating in a workshop.",
  "He is completing his homework.",
  "We are preparing for the presentation.",
  "I am reading a research paper.",
  "She is writing an essay.",
  "They are conducting an experiment.",
  "He is solving math problems.",
  "We are discussing the project.",
  "I am learning a new language.",
  "She is practicing piano lessons.",
  "They are attending a seminar.",
  "He is revising the syllabus.",
  "We are submitting the assignment.",
  "I am taking notes during the lecture.",
  "She is preparing flashcards.",
  "They are joining a study group.",
  "He is researching for his thesis.",
  "We are enrolling in a new course.",
  "How are you doing today?",
  "Can you help me with this task?",
  "What time is the meeting scheduled?",
  "Please let me know your availability.",
  "I appreciate your assistance.",
  "Could you please clarify that point?",
  "Let's catch up over coffee.",
  "I will get back to you shortly.",
  "Thank you for your prompt response.",
  "It's great to see you again.",
  "How was your weekend?",
  "I hope everything is going well.",
  "Let's schedule a meeting next week.",
  "Please share the document with me.",
  "I look forward to our collaboration.",
  "Let me know if you have any questions.",
  "I will send you the updated file.",
  "She is reviewing the project timeline.",
  "They are finalizing the design.",
  "He is sending the invoice today.",
  "We are discussing the new strategy.",
  "I will join the call at 4 PM.",
  "She is preparing the marketing plan.",
  "They are drafting the project proposal.",
  "He is analyzing the customer feedback.",
  "We are reviewing the performance report.",
  "I will share my thoughts by email.",
  "She is setting up the project folder.",
  "They are editing the final draft.",
  "He is updating the team on progress.",
  "We are organizing the client meeting.",
  "I will share the presentation file.",
  "She is working on the financial report.",
  "They are collecting data for the survey.",
  "He is proofreading the document.",
  "We are summarizing the project notes.",
  "I am checking the project status.",
  "She is adding notes to the document.",
  "They are cleaning up the workspace.",
  "He is planning the next steps."
];
  


const quoteDisplay = document.getElementById("quote-display");
const quoteInput = document.getElementById("quote-input");
const timerElement = document.getElementById("timer");
const wpmElement = document.getElementById("wpm");
const startBtn = document.getElementById("start-btn");

let startTime;
let timerInterval;
let currentQuote = "";

function getRandomQuote() {
  const randomIndex = Math.floor(Math.random() * quotes.length);
  return quotes[randomIndex];
}

function startGame() {
  currentQuote = getRandomQuote();
  quoteDisplay.textContent = currentQuote;
  quoteInput.value = "";
  quoteInput.focus();

  startTime = new Date();
  timerElement.textContent = "0";
  wpmElement.textContent = "0";

  clearInterval(timerInterval);
  timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
  const elapsedTime = Math.floor((new Date() - startTime) / 1000);
  timerElement.textContent = elapsedTime;
}

function calculateWPM() {
  const wordsTyped = quoteInput.value.trim().split(/\s+/).length;
  const elapsedTimeInMinutes = (new Date() - startTime) / 60000;
  return Math.round(wordsTyped / elapsedTimeInMinutes) || 0;
}

quoteInput.addEventListener("input", () => {
  const currentInput = quoteInput.value;
  if (currentInput === currentQuote) {
    clearInterval(timerInterval);
    const wpm = calculateWPM();
    wpmElement.textContent = wpm;
  }
});

startBtn.addEventListener("click", startGame);
